// ContextCell.swift

// This swift file includes the Table Cell Struct

import UIKit

public struct contextCell {
    var cellText: String
    var cellImage: UIImage
//      public init() {
//          self.cellText = cellText
//          self.cellImage = cellImage
//      }
}
